//
//  AppView.swift
//  Test Login
//
//  Created by Michele Diegoli on 08/07/24.
//

import SwiftUI

struct AppView: View {
    var body: some View {
        Text(String(localized: "app.view"))
    }
}

#Preview {
    AppView()
}

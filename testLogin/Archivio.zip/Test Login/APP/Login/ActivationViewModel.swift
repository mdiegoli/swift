//
//  ActivationViewModel.swift
//  Test Login
//
//  Created by Michele Diegoli on 08/07/24.
//

import Foundation

class ActivationViewModel: ObservableObject{
    @Published var authenticated: Bool = false
    @Published var nameText: String = ""
    @Published var passwordText: String = ""
    @Published var emptyFields: Bool = false
    @Published var wrongAccount: Bool = false
    @Published var loginDone: Bool = false


    
    init() {
        //logica con la quale decido se far vedere la form di login o no
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.authenticated = true
            //rimuovendo il commento la login è eseguita e l'app parte subito nella prima pagina
            //self.loginDone = true
        }
    }
    
    public func login(){
        if nameText.isEmpty || passwordText.isEmpty {
            self.emptyFields = true
        } else {
            self.emptyFields = false
            if nameText.elementsEqual("admin") == false || passwordText.elementsEqual("admin") == false {
                self.wrongAccount = true
            } else {
                self.loginDone = true
            }
        }
    }
        
}

//
//  ContentView.swift
//  Test Login
//
//  Created by Michele Diegoli on 08/07/24.
//

import SwiftUI

struct ActivationView: View {
    @StateObject var model: ActivationViewModel

    init() {
        self._model = StateObject(wrappedValue: ActivationViewModel())
        
    }
    
    var body: some View {
        if(!model.authenticated){
            VStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text(String(localized: "wait.autentication")).font(.custom("Copperplate", fixedSize: 18))
            }
            .padding()
        }else{
            if model.loginDone {
                AppView()
            } else {
                VStack {
                    Text(String(localized: "login.view")).font(.custom("Copperplate", fixedSize: 18))
                    TextField(String(localized: "username"), text: $model.nameText)
                    TextField(String(localized: "password"), text: $model.passwordText)
                    Button(String(localized:"login"), action: {
                        model.login()
                    }).font(.custom("Copperplate", fixedSize: 18))
                }.alert(String(localized: "login.error.emptyfield"),isPresented: $model.emptyFields) {}
                    .alert(String(localized: "login.error.wrongaccount"),isPresented: $model.wrongAccount) {}
            }
        }
    }
}

#Preview {
    ActivationView()
}


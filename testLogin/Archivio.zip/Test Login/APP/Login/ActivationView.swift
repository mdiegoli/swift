//
//  ContentView.swift
//  Test Login
//
//  Created by Michele Diegoli on 08/07/24.
//

import SwiftUI

struct ActivationView: View {
    @StateObject var model: ActivationViewModel

    init() {
        self._model = StateObject(wrappedValue: ActivationViewModel())
        
    }
    
    var body: some View {
        if(!model.authenticated){
            VStack {
                /*Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)*/
                Text(String(localized: "wait.autentication")).font(.custom("Copperplate", fixedSize: 18))
            }
            .padding()
        }else{
            if model.loginDone {
                AppView()
            } else {
                VStack {
                    Text(String(localized: "login.view")).font(.custom("Copperplate", fixedSize: 18))
                    TextField(String(localized: "username"), text: $model.nameText).padding(36)
                    TextField(String(localized: "password"), text: $model.passwordText).padding(36)
                    Button(String(localized:"login"), action: {
                        model.login()
                    }).font(.custom("Copperplate", fixedSize: 18)).buttonStyle(MyButtonStyle())
                }.alert(String(localized: "login.error.emptyfield"),isPresented: $model.emptyFields) {}
                    .alert(String(localized: "login.error.wrongaccount"),isPresented: $model.wrongAccount) {}
            }
        }
    }
}

#Preview {
    ActivationView()
}

struct MyButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(.gray)
            .foregroundStyle(.white)
            .clipShape(Capsule())
            .scaleEffect(configuration.isPressed ? 1.2 : 1)
            .animation(.easeOut(duration: 0.2), value: configuration.isPressed)
    }
}


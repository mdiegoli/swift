//
//  Utility.swift
//  Test Login
//
//  Created by Michele Diegoli on 09/07/24.
//

import Foundation
public class Utility {
    static var userDefault = UserDefaults.standard
    static let loginData = "LoginData"
    // write
    public static func writeAnyData(key: String, value: Any){
        userDefault.set(value, forKey: key)
        userDefault.synchronize()
    }

    // read int values
    public static func readIntData(key: String) -> Int{
        if userDefault.object(forKey: key) == nil {
            return 0
        } else {
            return userDefault.integer(forKey: key)
        }
    }

    // read string values
    public static func readStringData(key: String) -> String{
        if userDefault.object(forKey: key) == nil {
            return ""
        } else {
            return userDefault.string(forKey: key) ?? ""
        }
    }
    // read bool value
    public static func readBoolData(key: String, def: Bool) -> Bool{
        if userDefault.object(forKey: key) == nil {
            return def
        } else {
            return userDefault.bool(forKey: key)
        }
    }

    public static func deleteUserDefaultKey(key: String) -> Bool {
        userDefault.removeObject(forKey: key)
        if readStringData(key: key) == "" {
            return true
        }else{
            return false
        }

    }
    

}

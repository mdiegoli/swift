//
//  Test_LoginApp.swift
//  Test Login
//
//  Created by Michele Diegoli on 08/07/24.
//

import SwiftUI

@main
struct Test_LoginApp: App {
    var body: some Scene {
        WindowGroup {
            ActivationView()
        }
    }
}
